package HerenciaUPCasting1;

public class Child extends Parent {

    void PrintData() {
        System.out.println("method of  child class");
    }
}
