package HerenciaUPCasting1;

public class Parent {
    void PrintData() {
        System.out.println("method of parent class");
    }
}
