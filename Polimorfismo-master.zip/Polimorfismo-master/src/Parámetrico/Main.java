package Parámetrico;

import java.util.ArrayList;

public class Main {


    public static void main(String[] args) {

        ArrayList<Persona> personas = new ArrayList<>();
        ArrayList<Integer>  numeros = new ArrayList<>();



        Persona p1 = new Persona("Coco");

        personas.add(p1);

        numeros.add(1);

}
}