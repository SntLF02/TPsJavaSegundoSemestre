package Coherción;

public class Main {
    public static void main(String[] args) {

    int a,b;
        double suma2;
    a=3;
    b=5;

    Suma suma = new Suma();

    System.out.println("La suma de " +a+" "+b+" es "+suma.sumar(a,b));

    suma2= (double) a;



    }
}
