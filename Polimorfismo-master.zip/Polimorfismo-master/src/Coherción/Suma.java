package Coherción;

public class Suma {

    public double sumar(int numero1,int numero2){

        return numero1+numero2;
    }


}
