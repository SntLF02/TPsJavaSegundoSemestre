public class Main {
    public static void main(String[] args) {


        System.out.println(Math.pow(2, 31));
    }
}