package Herencia1;

public class Leon extends Animal{
    @Override
    public void comer() {
        System.out.println(" Yo como carne ");
    }
}
