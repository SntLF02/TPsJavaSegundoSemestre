package Herencia1;

public class Main {
    public static void main(String[] args) {
        Leon leon = new Leon();
        Vaca vaca = new Vaca();

        leon.comer();
        vaca.comer();
    }
}
