package Herencia1;

public class Vaca extends Animal{
    @Override
    public void comer() {
        System.out.println(" Yo como hierba");
    }
}
