package Herencia1;

public abstract class Animal {

    public abstract void comer();
}
