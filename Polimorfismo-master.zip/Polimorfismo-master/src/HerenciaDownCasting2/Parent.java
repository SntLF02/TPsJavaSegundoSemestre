package HerenciaDownCasting2;

public class Parent {
    String name;
    // A method which prints the data of the parent class
    void showMessage()
    {
        System.out.println("Parent method is called");
    }
}
